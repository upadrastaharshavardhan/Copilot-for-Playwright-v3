# Generated Test Suite — AI Co-Pilot for Playwright QA

Source: test_pack_10000_cases.xlsx
Generated: 2026-08-18T06:40:00.845Z
Language: Python (pytest-playwright)
Total test cases: 10000
Modules: 20

## What's in here

- `tests/` — one or more spec files per module. Each file holds a single,
  compact data-driven test function/loop backed by a `TEST_DATA` /
  `testData` array, so large test packs stay readable instead of exploding
  into thousands of near-duplicate functions.
- `features/` — one `.feature` (Gherkin) file per module, matching the
  chunking of `tests/`. Rows in the spreadsheet's Steps column that already
  read as Given/When/Then/And/But are kept as-is; plain-English rows are
  automatically classified into Given (setup), When (action), and
  Then (expected outcome) — no special formatting is required in Excel.
- `test_case_bank.csv` — every generated test case (ID, module, steps,
  data, expected result, priority, type, status) in one flat file for
  reporting/traceability.
- `traceability_matrix.csv` — maps each test case ID back to its source
  spreadsheet row and the generated file it lives in.

## Run it

```bash
pip install -r requirements.txt
playwright install
pytest -v
```

Set `BASE_URL` (env var) to point the suite at your environment before running.

## Wiring up real selectors

Every generated test currently uses either your custom Template's step code
(if one matched the module) or TODO placeholders. Search for `TODO` across
`tests/` to find spots that still need real Playwright locators.
